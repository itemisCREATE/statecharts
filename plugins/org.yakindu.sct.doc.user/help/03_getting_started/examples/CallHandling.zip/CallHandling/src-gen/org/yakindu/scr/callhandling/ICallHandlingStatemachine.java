package org.yakindu.scr.callhandling;
import org.yakindu.scr.IStatemachine;
import org.yakindu.scr.ITimedStatemachine;

public interface ICallHandlingStatemachine
		extends
			ITimedStatemachine,
			IStatemachine {

	public interface SCIUser {
		public void raiseAccept_call();
		public void raiseDismiss_call();

	}

	public SCIUser getSCIUser();

	public interface SCIPhone {
		public void raiseIncoming_call();
		public int getDuration();
		public void setDuration(int value);

	}

	public SCIPhone getSCIPhone();

}
