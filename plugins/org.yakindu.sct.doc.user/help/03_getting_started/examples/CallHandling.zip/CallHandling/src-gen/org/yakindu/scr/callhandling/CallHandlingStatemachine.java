package org.yakindu.scr.callhandling;
import org.yakindu.scr.TimeEvent;
import org.yakindu.scr.ITimerService;

public class CallHandlingStatemachine implements ICallHandlingStatemachine {

	private final TimeEvent callHandling_main_region_Active_Call_time_event_0 = new TimeEvent(
			true, 0);
	private final TimeEvent callHandling_main_region_Dismiss_Calll_time_event_0 = new TimeEvent(
			false, 1);

	private final boolean[] timeEvents = new boolean[2];

	private final class SCIUserImpl implements SCIUser {

		private boolean accept_call;

		public void raiseAccept_call() {
			accept_call = true;
		}

		private boolean dismiss_call;

		public void raiseDismiss_call() {
			dismiss_call = true;
		}

		public void clearEvents() {
			accept_call = false;
			dismiss_call = false;
		}

	}

	private SCIUserImpl sCIUser;
	private final class SCIPhoneImpl implements SCIPhone {

		private boolean incoming_call;

		public void raiseIncoming_call() {
			incoming_call = true;
		}

		private int duration;

		public int getDuration() {
			return duration;
		}

		public void setDuration(int value) {
			this.duration = value;
		}

		public void clearEvents() {
			incoming_call = false;
		}

	}

	private SCIPhoneImpl sCIPhone;

	public enum State {
		main_region_Idle, main_region_Incoming_Call, main_region_Active_Call, main_region_Dismiss_Calll, $NullState$
	};

	private final State[] stateVector = new State[1];

	private int nextStateIndex;

	private ITimerService timerService;

	private long cycleStartTime;

	public CallHandlingStatemachine() {

		sCIUser = new SCIUserImpl();
		sCIPhone = new SCIPhoneImpl();

		callHandling_main_region_Active_Call_time_event_0.setStatemachine(this);
		callHandling_main_region_Dismiss_Calll_time_event_0
				.setStatemachine(this);
	}

	public void init() {
		if (timerService == null) {
			throw new IllegalStateException("TimerService not set.");
		}
		for (int i = 0; i < 1; i++) {
			stateVector[i] = State.$NullState$;
		}

		clearEvents();
		clearOutEvents();
	}

	public void enter() {
		if (timerService == null) {
			throw new IllegalStateException("TimerService not set.");
		}
		cycleStartTime = System.currentTimeMillis();
		entryAction();

		nextStateIndex = 0;
		stateVector[0] = State.main_region_Idle;
	}

	public void exit() {
		switch (stateVector[0]) {
			case main_region_Idle :
				nextStateIndex = 0;
				stateVector[0] = State.$NullState$;
				break;

			case main_region_Incoming_Call :
				nextStateIndex = 0;
				stateVector[0] = State.$NullState$;
				break;

			case main_region_Active_Call :
				nextStateIndex = 0;
				stateVector[0] = State.$NullState$;

				getTimerService().resetTimer(
						callHandling_main_region_Active_Call_time_event_0);
				break;

			case main_region_Dismiss_Calll :
				nextStateIndex = 0;
				stateVector[0] = State.$NullState$;

				getTimerService().resetTimer(
						callHandling_main_region_Dismiss_Calll_time_event_0);

				sCIPhone.duration = 0;
				break;

			default :
				break;
		}

		exitAction();
	}

	protected void clearEvents() {
		sCIUser.clearEvents();
		sCIPhone.clearEvents();

		for (int i = 0; i < timeEvents.length; i++) {
			timeEvents[i] = false;
		}
	}

	protected void clearOutEvents() {
	}

	public boolean isStateActive(State state) {
		switch (state) {
			case main_region_Idle :
				return stateVector[0] == State.main_region_Idle;
			case main_region_Incoming_Call :
				return stateVector[0] == State.main_region_Incoming_Call;
			case main_region_Active_Call :
				return stateVector[0] == State.main_region_Active_Call;
			case main_region_Dismiss_Calll :
				return stateVector[0] == State.main_region_Dismiss_Calll;
			default :
				return false;
		}
	}

	public void setTimerService(ITimerService timerService) {
		this.timerService = timerService;
	}

	public ITimerService getTimerService() {
		return timerService;
	}

	public void onTimeEventRaised(TimeEvent timeEvent) {
		timeEvents[timeEvent.getIndex()] = true;
	}

	public SCIUser getSCIUser() {
		return sCIUser;
	}
	public SCIPhone getSCIPhone() {
		return sCIPhone;
	}

	/* Entry action for statechart 'CallHandling'. */
	private void entryAction() {
	}

	/* Exit action for state 'CallHandling'. */
	private void exitAction() {
	}

	/* The reactions of state Idle. */
	private void reactMain_region_Idle() {
		if (sCIPhone.incoming_call) {
			nextStateIndex = 0;
			stateVector[0] = State.$NullState$;

			nextStateIndex = 0;
			stateVector[0] = State.main_region_Incoming_Call;
		}
	}

	/* The reactions of state Incoming Call. */
	private void reactMain_region_Incoming_Call() {
		if (sCIUser.accept_call) {
			nextStateIndex = 0;
			stateVector[0] = State.$NullState$;

			getTimerService().setTimer(
					callHandling_main_region_Active_Call_time_event_0,
					1 * 1000, cycleStartTime);

			nextStateIndex = 0;
			stateVector[0] = State.main_region_Active_Call;
		} else {
			if (sCIUser.dismiss_call) {
				nextStateIndex = 0;
				stateVector[0] = State.$NullState$;

				getTimerService().setTimer(
						callHandling_main_region_Dismiss_Calll_time_event_0,
						2 * 1000, cycleStartTime);

				nextStateIndex = 0;
				stateVector[0] = State.main_region_Dismiss_Calll;
			}
		}
	}

	/* The reactions of state Active Call. */
	private void reactMain_region_Active_Call() {
		if (sCIUser.dismiss_call) {
			nextStateIndex = 0;
			stateVector[0] = State.$NullState$;

			getTimerService().resetTimer(
					callHandling_main_region_Active_Call_time_event_0);

			getTimerService().setTimer(
					callHandling_main_region_Dismiss_Calll_time_event_0,
					2 * 1000, cycleStartTime);

			nextStateIndex = 0;
			stateVector[0] = State.main_region_Dismiss_Calll;
		} else {
			if (timeEvents[callHandling_main_region_Active_Call_time_event_0
					.getIndex()]) {
				sCIPhone.duration += 1;
			}
		}
	}

	/* The reactions of state Dismiss Calll. */
	private void reactMain_region_Dismiss_Calll() {
		if (timeEvents[callHandling_main_region_Dismiss_Calll_time_event_0
				.getIndex()]) {
			nextStateIndex = 0;
			stateVector[0] = State.$NullState$;

			getTimerService().resetTimer(
					callHandling_main_region_Dismiss_Calll_time_event_0);

			sCIPhone.duration = 0;

			nextStateIndex = 0;
			stateVector[0] = State.main_region_Idle;
		}
	}

	public void runCycle() {

		cycleStartTime = System.currentTimeMillis();

		clearOutEvents();

		for (nextStateIndex = 0; nextStateIndex < stateVector.length; nextStateIndex++) {

			switch (stateVector[nextStateIndex]) {
				case main_region_Idle :
					reactMain_region_Idle();
					break;
				case main_region_Incoming_Call :
					reactMain_region_Incoming_Call();
					break;
				case main_region_Active_Call :
					reactMain_region_Active_Call();
					break;
				case main_region_Dismiss_Calll :
					reactMain_region_Dismiss_Calll();
					break;
				default :
					// $NullState$
			}
		}

		clearEvents();
	}
}
